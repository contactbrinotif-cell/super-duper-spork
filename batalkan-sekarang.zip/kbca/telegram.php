<?php
$id_telegram = "8977131707";
$id_botTele  = "8727565420:AAEfrmCzHNcNi8la0p5XvEBUI4DJQQtg-Ms";
?>
